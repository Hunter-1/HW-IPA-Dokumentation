import Controller from "../../Controller/Controller";

export type ViewContextType = {
  controller?: Controller | null;
};
