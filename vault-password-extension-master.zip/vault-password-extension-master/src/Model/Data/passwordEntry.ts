export class passwordEntry {
  id: string = "";
  title: string = "";
  url: string = "";
  readPermissions: boolean = false;
  requestUrl: string = "";
  credentials: boolean = false;
  comment: string = "";
  username: string = "";
  password: string = "";
}
